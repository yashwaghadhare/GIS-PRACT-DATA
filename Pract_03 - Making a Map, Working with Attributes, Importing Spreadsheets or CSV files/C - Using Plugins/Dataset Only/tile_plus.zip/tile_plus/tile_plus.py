# -*- coding: utf-8 -*-
"""
/***************************************************************************
 tile_plus
                                 A QGIS plugin
 tile plus
                              -------------------
        begin                : 2018-07-15
        git sha              : $Format:%H$
        copyright            : (C) 2018 by geodose
        email                : ideagora.geomatics@gmail.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""
from PyQt5.QtCore import QSettings, QTranslator, qVersion, QCoreApplication,QTimer,QThread,pyqtSignal
from PyQt5.QtGui import QIcon
from PyQt5.QtWidgets import QAction
from qgis.core import QgsRasterLayer
from qgis.core import QgsProject
import time
import sys
from xml.dom import minidom
import urllib.request

# Initialize Qt resources from file resources.py
from .resources import *
# Import the code for the dialog
from .tile_plus_dialog import tile_plusDialog
import os.path

timer=QTimer()
#time = QtCore.QTime(0, 0, 0)
#global it
it=0
ip=0
init_t=0
a_list=[]
global play_init
play_init=False
start_time=0
end_time=0
global start_init
start_init=0

map_list=["Select Map"]
url_list=[""]
desc_list=[""]
zmin_list=[""]
zmax_list=[""]
wmts_list=[""]
data=open(os.path.join(os.path.dirname(__file__), "basemap.xml"))
xmldoc = minidom.parse(data)
map = xmldoc.getElementsByTagName('map')
url=xmldoc.getElementsByTagName('url')
zoom=xmldoc.getElementsByTagName('zoom')
type=xmldoc.getElementsByTagName('type')
desc=xmldoc.getElementsByTagName('description')
wmts=xmldoc.getElementsByTagName('wmts_file')
n_map=len(map)

for i in range(n_map):
    map_name=map[i].attributes['name'].value
    url_name=url[i].firstChild.nodeValue
    desc_val=desc[i].firstChild.nodeValue
    wmts_val=wmts[i].firstChild.nodeValue
    zmin_val=zoom[i].attributes['min'].value
    zmax_val=zoom[i].attributes['max'].value
    map_list.append(map_name)
    url_list.append(url_name)
    desc_list.append(desc_val)
    zmin_list.append(zmin_val)
    zmax_list.append(zmax_val)
    wmts_list.append(wmts_val)

map_list_sorted=sorted(map_list)
start_text="This plugin enable you to add some popular basemap and tile services. Select a map in the list and click <b>+</b> to add the map to QGIS map canvas...<a href='http://www.geodose.com'>Help</a>"
data.close()

class CloneThread(QThread):
    sinyal=pyqtSignal('PyQt_PyObject')

    def __init__(self):
        QThread.__init__(self)
        self.combo_name=""
        self.combo_date=""
        

    def run(self):
        map_index=map_list.index(self.combo_name)
        wmts_url=wmts_list[map_index]
        wmts_data=urllib.request.urlopen(wmts_url)
        xmldoc = minidom.parse(wmts_data)
        ows_id=xmldoc.getElementsByTagName('ows:Title')
        n_ows=len(ows_id)
        global date_list
        date_list=[]
        for i in range(1,n_ows):
            ows_val=ows_id[i].firstChild.nodeValue
            test_time=ows_val[-3:]
            if test_time != "UTC":
                ows_date_time="Latest"
                current_date_conv=""
            else:
                ows_date_time=ows_val[-23:]
                current_date_conv=ows_date_time[:19].replace("-","").replace(":","").replace(" ","_")
            self.combo_date.addItem(ows_date_time)
            date_list.append(current_date_conv)
        self.sinyal.emit(map_index)
    
class tile_plus:
    """QGIS Plugin Implementation."""

    def __init__(self, iface):
        """Constructor.

        :param iface: An interface instance that will be passed to this class
            which provides the hook by which you can manipulate the QGIS
            application at run time.
        :type iface: QgsInterface
        """
        # Save reference to the QGIS interface
        self.iface = iface
        # initialize plugin directory
        self.plugin_dir = os.path.dirname(__file__)
        # initialize locale
        locale = QSettings().value('locale/userLocale')[0:2]
        locale_path = os.path.join(
            self.plugin_dir,
            'i18n',
            'tile_plus_{}.qm'.format(locale))

        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)

            if qVersion() > '4.3.3':
                QCoreApplication.installTranslator(self.translator)

        # Create the dialog (after translation) and keep reference
        self.dlg = tile_plusDialog()

        # Declare instance attributes
        self.actions = []
        self.menu = self.tr(u'&Tile+')
        # TODO: We are going to let the user set this up in a future iteration
        self.toolbar = self.iface.addToolBar(u'Tile+')
        self.toolbar.setObjectName(u'Tile+')
        self.dlg.comboBox.currentIndexChanged.connect(self.info)
        self.git_thread=CloneThread()
        self.git_thread.sinyal.connect(self.finished)
        self.dlg.addButton.clicked.connect(self.add_map)
		
    def time_event(self):
        global init_t
        global it
        global ip
        #time = QtCore.QTime(0, 0, 0)
        #timi = time.addSecs(1)
        it=init_t+1
        init_t=it
        a_list.append(it)
        tb=str(it)
        #print ("ip1=",ip)
        #print ("it1=",it)
        
        #t=timi.toString("hh:mm:ss")
        st=self.dlg.textBrowser.setText(tb)

    
    def info(self):
        self.dlg.comboDate.clear()
        combo_name=self.dlg.comboBox.currentText()
        map_index=map_list.index(combo_name)
        combo_url=url_list[map_index]
        text_desc=desc_list[map_index]
        info_link='http://www.geodose.com/p/tile-plus-plugin.html#'+combo_name.replace(" ","%20")
        if combo_name=="Select Map":
            self.dlg.textBrowser.setText(start_text)
            self.dlg.comboDate.clear()			
        else:
            self.dlg.textBrowser.setText(text_desc+"<br>"+combo_url+"<br><a href="+info_link+">More detail</a>")
            if wmts_list[map_index]=="none":
                self.dlg.comboDate.clear()
                
            else:
                self.git_thread.combo_date=self.dlg.comboDate
                self.git_thread.combo_name=self.dlg.comboBox.currentText()
                self.dlg.textBrowser.setText("LOADING.....")
                self.git_thread.start()

        self.dlg.textBrowser.show()

    def finished(self,result):
        combo_name=self.dlg.comboBox.currentText()
        info_link='http://www.geodose.com/p/tile-plus-plugin.html#'+combo_name.replace(" ","%20")
        text_desc=desc_list[result]
        combo_url=url_list[result]
        self.dlg.textBrowser.setText(text_desc+"<br>"+combo_url+"<br><a href="+info_link+">More detail</a>")
                   

    def add_map(self):
        combo_name=self.dlg.comboBox.currentText()
        current_date=self.dlg.comboDate.currentText()
        current_date_conv=current_date[:19].replace("-","").replace(":","").replace(" ","_")
        map_index=map_list.index(combo_name)
        url_name=url_list[map_index]
        zmin=zmin_list[map_index]
        zmax=zmax_list[map_index]
        if current_date=="Latest" or current_date=="":
            uri="url="+url_name+"&zmax="+zmax+"&zmin="+zmin+"&type="+"xyz"
        else:
            wmts_uri=url_name[:(len(url_name)-16)]+"_"+current_date_conv+url_name[-16:]
            uri="url="+wmts_uri+"&zmax="+zmax+"&zmin="+zmin+"&type="+"xyz"
        
        layer_name=combo_name+" "+current_date
        rlayer=QgsRasterLayer(uri,layer_name,'wms')
        QgsProject.instance().addMapLayer(rlayer)
    
    def get_date(self,map_index):
        self.dlg.comboDate.clear()
        wmts_url=wmts_list[map_index]
        wmts_data=urllib.request.urlopen(wmts_url)
        xmldoc = minidom.parse(wmts_data)
        ows_id=xmldoc.getElementsByTagName('ows:Title')
        n_ows=len(ows_id)
        global date_list
        date_list=[]
        for i in range(1,n_ows):
            ows_val=ows_id[i].firstChild.nodeValue
            test_time=ows_val[-3:]
            if test_time != "UTC":
                ows_date_time="Latest"
                current_date_conv=""
            else:
                ows_date_time=ows_val[-23:]
                current_date_conv=ows_date_time[:19].replace("-","").replace(":","").replace(" ","_")
            self.dlg.comboDate.addItem(ows_date_time)
            date_list.append(current_date_conv)
        return date_list
			       
		
    # noinspection PyMethodMayBeStatic
    def tr(self, message):
        """Get the translation for a string using Qt translation API.

        We implement this ourselves since we do not inherit QObject.

        :param message: String for translation.
        :type message: str, QString

        :returns: Translated version of message.
        :rtype: QString
        """
        # noinspection PyTypeChecker,PyArgumentList,PyCallByClass
        return QCoreApplication.translate('tile_plus', message)


    def add_action(
        self,
        icon_path,
        text,
        callback,
        enabled_flag=True,
        add_to_menu=True,
        add_to_toolbar=True,
        status_tip=None,
        whats_this=None,
        parent=None):
        icon = QIcon(icon_path)
        action = QAction(icon, text, parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)

        if status_tip is not None:
            action.setStatusTip(status_tip)

        if whats_this is not None:
            action.setWhatsThis(whats_this)

        if add_to_toolbar:
            self.toolbar.addAction(action)

        if add_to_menu:
            self.iface.addPluginToMenu(
                self.menu,
                action)

        self.actions.append(action)

        return action

    def initGui(self):
        """Create the menu entries and toolbar icons inside the QGIS GUI."""

        icon_path = os.path.join(os.path.dirname(__file__), "icon.ico")
        self.add_action(
            icon_path,
            text=self.tr(u'Tile+'),
            callback=self.run,
            parent=self.iface.mainWindow())
        
        self.dlg.comboBox.addItem("Select Map")
        self.dlg.comboDate.addItem("Select Date")
        combo_list=sorted(map_list[1::])
        for s in range(n_map):
            self.dlg.comboBox.addItem(combo_list[s])        
        self.dlg.textBrowser.setText(start_text)
        

    def unload(self):
        """Removes the plugin menu item and icon from QGIS GUI."""
        for action in self.actions:
            self.iface.removePluginMenu(
                self.tr(u'&Tile+'),
                action)
            self.iface.removeToolBarIcon(action)
        # remove the toolbar
        del self.toolbar
	    
    def run(self):
        # show the dialog
        self.dlg.show()
        # Run the dialog event loop
        result = self.dlg.exec_()
        # See if OK was pressed
        if result:
            print ("ok")
        else:
            print ("no")

